
Inputs: 

For each graph G, three text files and the Number of nodes (N) is given as follows:

    1) N                                          %% An integer number, number of nodes in G
    2) AdjacencyMatrix_of_Graph_G.txt             %% text file, N Rows, N columns, contain 0,1
    3) Node_Information_of_Graph_G.txt            %% text file, N Rows, 4 Columns
    4) SourceNode_StoppingCondition.txt           %% text file, a text file contains only two items (source node & condition of the Target)
   

 Remarks: 

   N: is an integer, which shows the Number of nodes in the given Graph G.
  
  "AdjacencyMatrix_of_Graph_G.txt" includes the Adjacency Matrix of graph G (for example Matrix A with size N*N ).
  if A(i,j) == 0, there is no edge between Node i & Node j. 
  if A(i,j) == 1, there is an edge between Node i & Node j. 

   Each node in the graph corresponds to a city, and
   "Node_Information_of_Graph_G.txt"  is a text file which has N row and each row indicates the information 
   of the corresponding node (infect corresponding city). This file has 4 columns including : 
   Node#, CityName, Population, HighestElevation. 

   "SourceNode_StoppingCondition.txt", is a text file which has only two columns and one row (only two items: source node & condition of the Target node)

  
 
Outputs:

Your DFS and/or BFS search program will create two text files  for each graph G with N nodes (N here is =6) as follows:
    1)  Result_of_BFS_from_Source_to_Targetc.txt
    2)  Result_of_DFS_from_Source_to_Target_N_6.txt
    An example of these files are shown in the current folder. They contain only one column a tuple of three elements of information each visited node
    as (City: XX , Pop: XX, Elevation: XX) during the search such BFS or DFS from the source node to the
    target node in the graph. The search stop when the algorithm encounter a node that satisfies condition of the Target or all
    Graph nodes are visited and no node found as the target, and all the results of visited nodes
    are reported in these two files.

    These two text files should be handed with your source codes, and the details of your assignment report.

